# iorad for Zendesk

launch the app from nav bar in the zendesk agent view.

Create step-by-step tutorial and post straight to your selected Zendesk Help Center section.

## Release Note

### Version 2.1.0
* Added the addToHelpCenterAsDraft App setting.
Users can now decide whether or not to save the tutorial as a draft in the navbar app view.
