# Iorad App for Zendesk

launch the app from nav bar in the zendesk agent view.

Create step-by-step tutorial and post straight to your selected Zendesk Help Center section.
